import {_electron as electron} from 'playwright';import fs from 'node:fs/promises';import path from 'node:path';import http from 'node:http';import assert from 'node:assert/strict';
const root=path.resolve('work/credentials-ui');await fs.rm(root,{recursive:true,force:true});await fs.mkdir(root,{recursive:true});const key='test-persistent-secret-123';let auth;
const server=http.createServer(async(req,res)=>{auth=req.headers.authorization;for await(const chunk of req){}res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({choices:[{message:{content:JSON.stringify({title:'Test',summary:'Özet',content:'İçerik',parentAddition:'Eklenti',tags:[],links:[],warnings:[]})},finish_reason:'stop'}]}));});await new Promise(r=>server.listen(0,'127.0.0.1',r));const base=`http://127.0.0.1:${server.address().port}/v1`;
let app,page;
async function launch(){app=await electron.launch({...(process.env.HAFIZA_PACKAGE?{executablePath:path.resolve(process.env.HAFIZA_PACKAGE),args:[]}:{args:['.']}),env:{...process.env,HAFIZA_TEST_DATA:root}});page=await app.firstWindow();await page.waitForFunction(()=>document.title.includes('Hafıza ·'));await page.locator('[data-page="settings"]').click();}
async function close(){await app.evaluate(({app})=>app.exit(0)).catch(()=>{});await app.close().catch(()=>{});app=null;}
async function save(){await page.locator('#save-settings').click();await page.waitForFunction(()=>!document.querySelector('#operation').hidden===false);assert.equal(await page.locator('#persistent-error').isVisible(),false);}
async function request(){await page.evaluate(()=>window.hafiza.call('analysis:test',{text:'Örnek kaynak metni. '.repeat(20),prompt:'Bilgiyi düzenle.',extra:''}));}
try{
 await launch();await page.locator('#api-base').fill(base);await page.locator('#api-model').fill('test-model');await page.locator('#api-key').fill(key);await save();assert.equal(await page.locator('#api-key').inputValue(),'************');assert.ok(!(await fs.readFile(root+'/settings.json','utf8')).includes(key));assert.ok(!(await fs.readFile(root+'/api-credentials.json','utf8')).includes(key));await close();
 await launch();assert.equal(await page.locator('#api-key').inputValue(),'************');await request();assert.equal(auth,'Bearer '+key);
 await page.locator('#extra-prompt').fill('Kısa özet kullan.');await save();await request();assert.equal(auth,'Bearer '+key);
 await page.locator('#api-key').fill('');await save();assert.equal(await page.locator('#api-key').inputValue(),'************');await request();assert.equal(auth,'Bearer '+key);
 await page.locator('#api-base').fill(base+'/other');await save();assert.equal(await page.locator('#api-key').inputValue(),'');await request();assert.equal(auth,undefined);
 await page.locator('#api-base').fill(base);await save();assert.equal(await page.locator('#api-key').inputValue(),'************');await request();assert.equal(auth,'Bearer '+key);
 await page.locator('#remove-key').check();await save();assert.equal(await page.locator('#api-key').inputValue(),'');await close();await launch();assert.equal(await page.locator('#api-key').inputValue(),'');await request();assert.equal(auth,undefined);
 console.log('PASS persistent masked key: restart, real mock API auth, unchanged/blank saves, endpoint isolation, explicit delete and restart.');
}finally{if(app)await close();await new Promise(r=>server.close(r));}
