import {_electron as electron} from 'playwright';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import path from 'node:path';
const app=await electron.launch({executablePath:path.resolve('dist/Hafiza-1.0.9-Linux-x86_64.AppImage'),env:{...process.env,HAFIZA_TEST_DATA:path.resolve('work/taskbar-test')},timeout:30000});
try {
 const page=await app.firstWindow();await page.waitForSelector('#api-indicator');
 const id=await app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].getNativeWindowHandle().readUInt32LE(0));
 const props=execFileSync('xprop',['-id',`0x${id.toString(16)}`,'-f','_NET_WM_ICON','32c','_NET_WM_ICON','WM_CLASS','_NET_WM_STATE','_KDE_NET_WM_DESKTOP_FILE'],{encoding:'utf8',maxBuffer:8*1024*1024});
 const icon=props.match(/_NET_WM_ICON\(CARDINAL\) = ([^\n]+)/);assert.ok(icon,'Pencere simgesinin piksel verisi gerekli.');const values=icon[1].split(',').map(Number);assert.deepEqual(values.slice(0,2),[128,128]);assert.equal(values.length,2+128*128);assert.ok(values.slice(2).some(value=>value>>>24>0),'Simge görünür pikseller içermeli.');assert.doesNotMatch(props,/_NET_WM_STATE_SKIP_TASKBAR/);assert.match(props,/WM_CLASS\(STRING\) = "hafiza", "hafiza"/);
 assert.match(props,/_KDE_NET_WM_DESKTOP_FILE\(UTF8_STRING\) = "hafiza"/);
 console.log('PASS: packaged window has native icon, matching hafiza WM_CLASS, and is not hidden from taskbar.');
}finally{await app.evaluate(({app})=>app.exit(0)).catch(()=>{});await app.close().catch(()=>{});}
