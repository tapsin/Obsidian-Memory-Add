import {_electron as electron} from 'playwright';
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
const dir=path.resolve('work/live-source');await fs.mkdir(dir,{recursive:true});
const app=await electron.launch({args:['.'],env:{...process.env,HAFIZA_TEST_DATA:dir}});
try{const page=await app.firstWindow();const result=await page.evaluate(()=>window.hafiza.call('source:fetch','https://www.electronjs.org/blog/electron-40-0'));assert.ok(result.markdown.length>500);console.log('PASS real HTTPS source:',result.title,result.markdown.length,'characters');const error=await page.evaluate(()=>window.hafiza.call('source:fetch','https://hafiza-does-not-exist.invalid').catch(e=>e.message));assert.match(error,/DNS|adres|bağlantı/i);assert.ok(!/^fetch failed$/i.test(error));console.log('PASS friendly DNS error:',error);}finally{await app.evaluate(({app})=>app.exit(0)).catch(()=>{});await app.close().catch(()=>{});}
