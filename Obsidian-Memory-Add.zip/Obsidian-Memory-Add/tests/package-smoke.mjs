import {_electron as electron} from 'playwright';
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
const data=path.resolve('work/final-package-data');await fs.mkdir(data,{recursive:true});
const app=await electron.launch({executablePath:path.resolve('dist/Hafiza-1.0.9-Linux-x86_64.AppImage'),args:[],env:{...process.env,HAFIZA_TEST_DATA:data},timeout:30000});
try{const page=await app.firstWindow();await page.waitForSelector('#api-indicator');await page.waitForFunction(()=>document.querySelector('#active-model').textContent==='gpt-4.1-mini');assert.equal(await page.title(),'Hafıza · 1.0.9');const cfg=await page.evaluate(()=>window.hafiza.call('settings:get'));assert.equal(cfg.hasKey,false);assert.ok(cfg.profiles[0].prompt.includes('kaynaklara sadık'));await page.screenshot({path:'work/final-appimage.png',fullPage:true});console.log('PASS: actual AppImage window, packaged IPC, clean defaults, no --no-sandbox flag.');}finally{await app.evaluate(({app})=>app.exit(0)).catch(()=>{});await app.close().catch(()=>{});}
