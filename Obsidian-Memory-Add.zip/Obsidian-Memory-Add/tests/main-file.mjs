import {_electron as electron} from 'playwright';
import fs from 'node:fs/promises';import path from 'node:path';import assert from 'node:assert/strict';
const dir=path.resolve('work/main-file-test');await fs.rm(dir,{recursive:true,force:true});await fs.mkdir(dir+'/vault/Konu',{recursive:true});await fs.mkdir(dir+'/data',{recursive:true});await fs.writeFile(dir+'/vault/IQ.md','# IQ\n');await fs.writeFile(dir+'/vault/Konu/Dersler.md','# Dersler\n');await fs.writeFile(dir+'/outside.md','# Outside\n');await fs.writeFile(dir+'/data/settings.json',JSON.stringify({vault:dir+'/vault'}));
let app;
const launch=async()=>{app=await electron.launch({args:['.','--no-sandbox'],env:{...process.env,HAFIZA_TEST_DATA:dir+'/data'}});const page=await app.firstWindow();await page.waitForSelector('.note');return page;};
try{
 let page=await launch();assert.equal(await page.locator('.note input:checked').inputValue(),'IQ.md');
 await app.evaluate(({dialog},file)=>{dialog.showOpenDialog=async()=>({canceled:false,filePaths:[file]});},dir+'/vault/Konu/Dersler.md');
 await page.locator('#choose-main-note').click();await page.waitForFunction(()=>document.querySelector('.note input:checked')?.value==='Konu/Dersler.md');assert.deepEqual(JSON.parse(await fs.readFile(dir+'/data/settings.json','utf8')).mainNotesByVault[dir+'/vault'],['Konu/Dersler.md']);
 await app.evaluate(({app})=>app.exit(0)).catch(()=>{});await app.close().catch(()=>{});page=await launch();assert.equal(await page.locator('.note input:checked').inputValue(),'Konu/Dersler.md');
 await app.evaluate(({dialog},file)=>{dialog.showOpenDialog=async()=>({canceled:false,filePaths:[file]});},dir+'/outside.md');await page.locator('#choose-main-note').click();await page.locator('#persistent-error').waitFor({state:'visible'});assert.equal(await page.locator('.note input:checked').inputValue(),'Konu/Dersler.md');
 console.log('PASS main file picker: IQ default, actual file selection, remembered after restart, outside-vault rejection.');
}finally{if(app){await app.evaluate(({app})=>app.exit(0)).catch(()=>{});await app.close().catch(()=>{});}}
