import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {canonicalUrl,endpointUrl,extractHtml,validateAnalysis,readParents,makePlan,commitPlan,undoTransaction,history,safePath,listNotes,fetchSource,analyze,DEFAULT_PROMPT} from '../app/core.mjs';
const example={title:'Ajan Mimarileri',summary:'Kaynağın özeti.',content:'## Mimari\n\nAjanlar araçları kullanır.',parentAddition:'Ajan mimarisinin kısa açıklaması.',tags:['yapay-zeka'],links:['Yapay Zekâ'],warnings:[],model:'test-model'};
const source={url:'https://example.com/article',originalUrl:'https://example.com/article',title:'Örnek',markdown:'Bir kaynak metni. '.repeat(30)};
async function vault(t){const root=await fs.mkdtemp(path.join(os.tmpdir(),'hafiza-test-'));t.after(()=>fs.rm(root,{recursive:true,force:true}));await fs.writeFile(path.join(root,'Yapay Zekâ.md'),'# Yapay Zekâ\n\nKendi düşüncem.\n');return root;}
async function mockServer(t,handler){const server=http.createServer(handler);await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>server.close(r)));return `http://127.0.0.1:${server.address().port}`;}
test('URL normalleştirme yalnızca takip parametrelerini temizler',()=>{assert.equal(canonicalUrl('https://example.com/a?utm_source=x&b=2&a=1#section'),'https://example.com/a?a=1&b=2');assert.throws(()=>canonicalUrl('file:///etc/passwd'));assert.throws(()=>canonicalUrl('https://a:b@example.com'));});
test('API uç noktası HTTPS veya yerel model gerektirir',()=>{assert.equal(endpointUrl('https://example.com/v1/'),'https://example.com/v1/chat/completions');assert.equal(endpointUrl('http://localhost:11434/v1/chat/completions'),'http://localhost:11434/v1/chat/completions');assert.throws(()=>endpointUrl('http://example.com/v1'));});
test('HTML ayrıştırma script çalıştırmaz ve asıl makaleyi korur',()=>{const s=extractHtml(`<html><head><title>Öğrenme</title></head><body><nav>Giriş Reklam</nav><article><h1>Öğrenme</h1><p>${'Kalıcı bilgi bağlantılar kurarak oluşur. '.repeat(20)}</p><a href="/kaynak">Referans</a><script>throw Error('executed')</script></article></body></html>`,'https://example.com/a');assert.match(s.markdown,/Kalıcı bilgi/);assert.match(s.markdown,/https:\/\/example.com\/kaynak/);assert.doesNotMatch(s.markdown,/throw Error/);});
test('Model çıktısı doğrulanır, hayali wikilinkler temizlenir',()=>{const v=validateAnalysis({...example,content:'[[Yapay Zekâ]] ve [[Olmayan Not]]',links:['Yapay Zekâ','Olmayan Not']},['Yapay Zekâ.md']);assert.deepEqual(v.links,['Yapay Zekâ']);assert.equal(v.content,'[[Yapay Zekâ]] ve Olmayan Not');assert.throws(()=>validateAnalysis({title:'eksik'}));});
test('Vault taraması gizli ve symlink dosyaları dışlar',async t=>{const root=await vault(t);await fs.mkdir(path.join(root,'.obsidian'));await fs.writeFile(path.join(root,'.obsidian','secret.md'),'test');await fs.symlink('/tmp',path.join(root,'linked'));assert.equal((await listNotes(root)).length,1);await assert.rejects(()=>safePath(root,'../outside'));await assert.rejects(()=>safePath(root,'linked/test.md'));});
test('Kaynak notu, bağlantı, günlük ve kayıpsız geri alma',async t=>{const root=await vault(t);const original=await fs.readFile(path.join(root,'Yapay Zekâ.md'),'utf8');const parents=await readParents(root,['Yapay Zekâ.md']);const plan=await makePlan(root,source,example,parents,'linked');assert.equal(plan.changes.length,2);await commitPlan(root,plan);const parent=await fs.readFile(path.join(root,'Yapay Zekâ.md'),'utf8');assert.ok(parent.startsWith(original.trimEnd()));assert.match(parent,/\[\[Kaynaklar\//);assert.equal((await history(root))[0].status,'committed');await undoTransaction(root,plan.id);assert.equal(await fs.readFile(path.join(root,'Yapay Zekâ.md'),'utf8'),original);await assert.rejects(()=>fs.access(path.join(root,plan.changes[0].path)));assert.equal((await history(root))[0].status,'undone');});
test('Doğrudan ekleme ayrı kaynak dosyası oluşturmaz',async t=>{const root=await vault(t);const plan=await makePlan(root,source,example,await readParents(root,['Yapay Zekâ.md']),'append');assert.equal(plan.changes.length,1);await commitPlan(root,plan);assert.match(await fs.readFile(path.join(root,'Yapay Zekâ.md'),'utf8'),/Ajanlar araçları/);});
test('Analizden sonra değişmiş ana nota yazılmaz',async t=>{const root=await vault(t);const parents=await readParents(root,['Yapay Zekâ.md']);await fs.appendFile(path.join(root,'Yapay Zekâ.md'),'Yeni düşünce');await assert.rejects(()=>makePlan(root,source,example,parents),/değişti/);});
test('Önizlemeden sonra değişmiş ana nota yazılmaz',async t=>{const root=await vault(t);const plan=await makePlan(root,source,example,await readParents(root,['Yapay Zekâ.md']));await fs.appendFile(path.join(root,'Yapay Zekâ.md'),'Yeni düşünce');await assert.rejects(()=>commitPlan(root,plan),/değişti/);await assert.rejects(()=>fs.access(path.join(root,plan.changes[0].path)));});
test('Sonradan düzenlenmiş dosyada geri alma değişiklikleri korur',async t=>{const root=await vault(t);const plan=await makePlan(root,source,example,await readParents(root,['Yapay Zekâ.md']));await commitPlan(root,plan);await fs.appendFile(path.join(root,'Yapay Zekâ.md'),'Sonradan yazıldı');await assert.rejects(()=>undoTransaction(root,plan.id),/değişmiş/);assert.match(await fs.readFile(path.join(root,'Yapay Zekâ.md'),'utf8'),/Sonradan yazıldı/);});
test('Tekrar aktarım farklı başlıkla bile engellenir',async t=>{const root=await vault(t);await fs.writeFile(path.join(root,'İkinci.md'),'# İkinci\n');const plan=await makePlan(root,source,example,await readParents(root,['Yapay Zekâ.md']));await commitPlan(root,plan);const second=await makePlan(root,source,{...example,title:'Farklı başlık'},await readParents(root,['İkinci.md']));await assert.rejects(()=>commitPlan(root,second),/daha önce/);});
test('Yarım kalmış işlem özgün metne döner',async t=>{const root=await vault(t);const plan=await makePlan(root,source,example,await readParents(root,['Yapay Zekâ.md']));await fs.mkdir(path.join(root,'.hafiza/transactions'),{recursive:true});await fs.writeFile(path.join(root,`.hafiza/transactions/${plan.id}.json`),JSON.stringify({...plan,status:'prepared'}));await fs.mkdir(path.join(root,'Kaynaklar'));await fs.writeFile(path.join(root,plan.changes[0].path),plan.changes[0].after);await undoTransaction(root,plan.id);assert.equal((await history(root))[0].status,'undone');await assert.rejects(()=>fs.access(path.join(root,plan.changes[0].path)));});
test('Kaynak alma yönlendirmeyi takip eder, içerik türünü denetler',async t=>{const base=await mockServer(t,(req,res)=>{if(req.url==='/go'){res.writeHead(302,{location:'/article'});res.end();}else if(req.url==='/pdf'){res.writeHead(200,{'content-type':'application/pdf'});res.end('pdf');}else{res.writeHead(200,{'content-type':'text/plain'});res.end('Kaynak içeriği ve önemli bilgiler. '.repeat(20));}});const s=await fetchSource(base+'/go');assert.equal(s.url,base+'/article');assert.equal(s.originalUrl,base+'/go');await assert.rejects(()=>fetchSource(base+'/pdf'),/PDF/);});
test('Gerçek HTTP API akışı, JSON doğrulama ve kesilme uyarısı',async t=>{let payload,auth;const base=await mockServer(t,async(req,res)=>{auth=req.headers.authorization;let body='';for await(const chunk of req)body+=chunk;payload=JSON.parse(body);res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({choices:[{finish_reason:'stop',message:{content:JSON.stringify(example)}}]}));});const output=await analyze({...source,markdown:'a'.repeat(7000)},[{path:'Yapay Zekâ.md',content:'Notum'}],{baseUrl:base+'/v1',model:'test-model',prompt:DEFAULT_PROMPT,maxChars:4000,jsonMode:true},'dummy-test-key');assert.equal(auth,'Bearer dummy-test-key');assert.equal(payload.model,'test-model');assert.equal(JSON.parse(payload.messages[1].content).source.markdown.length,4000);assert.ok(output.warnings.some(w=>w.includes('4000')));});
test('API hatası anahtar veya sunucu gövdesini kullanıcıya sızdırmaz',async t=>{const base=await mockServer(t,(_req,res)=>{res.writeHead(401);res.end('secret-key-do-not-display');});await assert.rejects(()=>analyze(source,[],{baseUrl:base,model:'test',prompt:DEFAULT_PROMPT},'secret'),e=>e.message.includes('401')&&!e.message.includes('secret'));});

test('Kaynak ağ hatası DNS nedenini Türkçe gösterir, gizli mesajı göstermez',async()=>{
 const broken=async()=>{throw new TypeError('fetch failed secret text',{cause:Object.assign(new Error('private details'),{code:'ENOTFOUND'})});};
 await assert.rejects(()=>fetchSource('https://does-not-exist.invalid',undefined,broken),e=>e.message.includes('DNS')&&e.message.includes('ENOTFOUND')&&!e.message.includes('private')&&!e.message.includes('secret'));
});
test('Kaynak taşıyıcısı yönlendirmede de kullanılır ve kimlik bilgisi göndermez',async()=>{
 const urls=[];const request=async(url,options)=>{urls.push(url);assert.equal(options.credentials,'omit');return urls.length===1?new Response(null,{status:302,headers:{location:'/final'}}):new Response('Kaynak bilgisi. '.repeat(30),{headers:{'content-type':'text/plain'}});};
 const s=await fetchSource('https://example.com/start',undefined,request);assert.deepEqual(urls,['https://example.com/start','https://example.com/final']);assert.equal(s.url,'https://example.com/final');
});

// JSON repair: real models (local or small hosted) frequently emit the kind of
// output the strict JSON.parse rejects. These tests confirm the repair routine
// recovers a usable object from a few common failure shapes.
test('Tamirci: ```json kod bloğu içinde gelen çıktıyı ayıklar',()=>{
 const wrapped='```json\n'+JSON.stringify(example)+'\n```';
 const v=validateAnalysis(wrapped);
 assert.equal(v.title,example.title);
});
test('Tamirci: string içinde kaçmamış tırnakları kurtarır',()=>{
 const broken='{"title":"Ajan \"Mimarileri\"","summary":"Kaynağın özeti.","content":"## Mimari\\n\\nAjanlar araçları kullanır.","parentAddition":"Ajan mimarisinin kısa açıklaması.","tags":["yapay-zeka"],"links":[],"warnings":[]}';
 const v=validateAnalysis(broken);
 assert.equal(v.title,'Ajan "Mimarileri"');
});
test('Tamirci: sondaki virgül ve eksik kapanış kümesini düzeltir',()=>{
 const broken='{"title":"Başlık","summary":"Özet","content":"İçerik","parentAddition":"Eklenecek bölüm","tags":["t"],,"warnings":[]';
 const v=validateAnalysis(broken);
 assert.equal(v.tags[0],'t');
});
test('Tamirci: çözülemeyen çıktıda ham metni hata içinde döndürür',()=>{
 const broken='{"title":"Başlık","summary":'; // intentionally truncated
 assert.throws(()=>validateAnalysis(broken),e=>e.message.includes('ham çıktı'));
});

test('Seçilen ana dosya vault içinde gerçek bir Markdown dosyası olmalıdır',async t=>{
 const {selectedMainFile}=await import('../app/core.mjs');const root=await vault(t);
 assert.equal(await selectedMainFile(root,path.join(root,'Yapay Zekâ.md')),'Yapay Zekâ.md');
 await assert.rejects(()=>selectedMainFile(root,path.join(root,'olmayan.md')));
 await assert.rejects(()=>selectedMainFile(root,path.join(root,'../outside.md')));
 await fs.symlink(path.join(root,'Yapay Zekâ.md'),path.join(root,'alias.md'));
 await assert.rejects(()=>selectedMainFile(root,path.join(root,'alias.md')),/Sembolik/);
});
test('IQ başlangıç seçimidir, geçerli hatırlanan ana not önceliklidir',async()=>{
 const {preferredMainNotes}=await import('../app/core.mjs');const notes=[{path:'IQ.md'},{path:'Konu/Dersler.md'}];
 assert.deepEqual(preferredMainNotes(notes),['IQ.md']);
 assert.deepEqual(preferredMainNotes(notes,['Konu/Dersler.md']),['Konu/Dersler.md']);
 assert.deepEqual(preferredMainNotes(notes,['Silinmiş.md']),['IQ.md']);
});
test('Kısa ana not bağlantıları gerçek yola çevrilir; hayali Markdown ve uyarı bağlantıları kaldırılır',()=>{
 const r=validateAnalysis({...example,content:'[[Dersler]] ve [Ders](Konu/Dersler.md) ve [Hayali](Hayali.md) ve [[Olmayan]]',warnings:['[[Yeni Konu]] önerisi'],links:['Dersler']},['Konu/Dersler.md']);
 assert.match(r.content,/\[\[Konu\/Dersler\]\]/);assert.match(r.content,/\[\[Konu\/Dersler\|Ders\]\]/);
 assert.doesNotMatch(r.content,/\]\(Hayali.md\)|\[\[Olmayan\]\]/);assert.equal(r.warnings[0],'Yeni Konu önerisi');assert.deepEqual(r.links,['Konu/Dersler']);
});
test('Kod örnekleri korunur, belirsiz kısa not bağlantısı üretilmez',async()=>{
 const {sanitizeNoteLinks}=await import('../app/core.mjs');
 assert.equal(sanitizeNoteLinks('`[[Örnek]]` ve [[Ders]]',['A/Ders.md','B/Ders.md']),'`[[Örnek]]` ve Ders');
});
