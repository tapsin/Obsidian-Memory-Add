import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {fetchSource} from '../app/core.mjs';

async function server(t) {
 const app=http.createServer((req,res)=>{
  if(req.url==='/headers')return;
  if(req.url==='/body'){res.writeHead(200,{'content-type':'text/plain'});res.write('İlk bölüm. ');return;}
  res.writeHead(200,{'content-type':'text/html'});
  res.end(`<html><title>Kaynak</title><article><h1>Kaynak</h1><p>${'Kaynak bilgisi ve açıklamalar. '.repeat(20)}</p></article></html>`);
 });
 await new Promise(resolve=>app.listen(0,'127.0.0.1',resolve));
 t.after(()=>{app.closeAllConnections();return new Promise(resolve=>app.close(resolve));});
 return `http://127.0.0.1:${app.address().port}`;
}
for(const [route,message] of [['headers',/bağlantıya/],['body',/indirilmesi/]]) {
 test(`Yanıt vermeyen ${route} aşaması süre sınırında sonlanır ve yeniden alınabilir`,async t=>{
  const base=await server(t);const stages=[];const start=Date.now();
  await assert.rejects(()=>fetchSource(base+'/'+route,undefined,fetch,{timeoutMs:150,onProgress:s=>stages.push(s)}),error=>{
   assert.match(error.message,message);assert.match(error.message,/bekleme sınırına/);assert.doesNotMatch(error.message,/iptal/);return true;
  });
  assert.ok(Date.now()-start<2000);
  assert.deepEqual(stages,route==='headers'?['connecting']:['connecting','downloading']);
  const recovered=await fetchSource(base+'/ok');assert.match(recovered.markdown,/Kaynak bilgisi/);
 });
}
test('Başlık ve gövde beklerken iptal zaman aşımından ayrılır',async t=>{
 const base=await server(t);
 for(const route of ['headers','body']) {
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),100);
  try{await assert.rejects(()=>fetchSource(base+'/'+route,controller.signal),/Kaynak alma işlemi iptal edildi/);}
  finally{clearTimeout(timer);}
 }
});
test('Başarılı kaynak bağlantı, indirme ve ayıklama aşamalarını bildirir',async t=>{
 const base=await server(t);const stages=[];
 await fetchSource(base+'/ok',undefined,fetch,{onProgress:s=>stages.push(s)});
 assert.deepEqual(stages,['connecting','downloading','extracting']);
});
