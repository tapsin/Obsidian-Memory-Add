import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {endpointUrl} from './core.mjs';

async function atomicWrite(file,text){
  const temp=file+'.'+crypto.randomUUID()+'.tmp';
  try{await fs.writeFile(temp,text,{flag:'wx',mode:0o600});await fs.rename(temp,file);await fs.chmod(file,0o600);}finally{await fs.unlink(temp).catch(()=>{});}
}
export class CredentialStore{
  constructor(directory,{native=null,nativeAvailable=()=>false}={}){this.directory=directory;this.native=native;this.nativeAvailable=nativeAvailable;this.records={};}
  id(endpoint){return crypto.createHash('sha256').update(endpointUrl(endpoint)).digest('hex');}
  async init(){
    await fs.mkdir(this.directory,{recursive:true,mode:0o700});
    this.file=path.join(this.directory,'api-credentials.json');this.masterFile=path.join(this.directory,'api-credentials.key');
    try{const value=JSON.parse(await fs.readFile(this.file,'utf8'));if(value.version!==1||!value.records||typeof value.records!=='object'||Array.isArray(value.records))throw new Error('format');this.records=value.records;}
    catch(e){if(e.code!=='ENOENT')throw new Error('API anahtar deposu okunamadı. Kayıtlar silinmedi; uygulama veri klasöründeki api-credentials.json dosyasını kontrol edin.');}
    return this;
  }
  async saveRecords(next){await atomicWrite(this.file,JSON.stringify({version:1,records:next},null,2));this.records=next;}
  has(endpoint){return !!this.records[this.id(endpoint)];}
  mode(endpoint){return this.records[this.id(endpoint)]?.mode||null;}
  async master(create=false){
    try{const key=await fs.readFile(this.masterFile);if(key.length!==32)throw new Error('invalid');return key;}
    catch(e){
      if(e.code==='ENOENT'&&create){const key=crypto.randomBytes(32);try{await fs.writeFile(this.masterFile,key,{flag:'wx',mode:0o600});return key;}catch(writeError){if(writeError.code==='EEXIST')return this.master(false);throw writeError;}}
      throw new Error('Yerel anahtar deposunun şifreleme dosyası bulunamadı veya okunamadı. API anahtar kaydı silinmedi.');
    }
  }
  async get(endpoint){
    const record=this.records[this.id(endpoint)];if(!record)return '';
    if(record.mode==='native'){
      if(!this.nativeAvailable())throw new Error('API anahtarı kayıtlı, ancak işletim sisteminin kasası şu an kapalı. Kasayı açın veya anahtarı yeniden girip kalıcı yerel kayda geçin.');
      try{return this.native.decryptString(Buffer.from(record.data,'base64'));}catch{throw new Error('Kayıtlı API anahtarının şifresi açılamadı. Kayıt silinmedi; anahtarı yeniden girerek güncelleyebilirsiniz.');}
    }
    if(record.mode!=='local')throw new Error('Bilinmeyen API anahtar kaydı. Kayıt silinmedi.');
    const master=await this.master();
    try{const decipher=crypto.createDecipheriv('aes-256-gcm',master,Buffer.from(record.iv,'base64'));decipher.setAAD(Buffer.from(this.id(endpoint)));decipher.setAuthTag(Buffer.from(record.tag,'base64'));return Buffer.concat([decipher.update(Buffer.from(record.data,'base64')),decipher.final()]).toString('utf8');}
    catch{throw new Error('Kayıtlı API anahtarının şifresi açılamadı. Anahtar kaydı silinmedi.');}
  }
  async set(endpoint,value){
    if(typeof value!=='string'||!value.trim()||value.length>20000)throw new Error('Geçerli bir API anahtarı girin.');
    const id=this.id(endpoint),key=value.trim();let record;
    if(this.nativeAvailable()){try{record={mode:'native',data:this.native.encryptString(key).toString('base64')};}catch{/* An unavailable OS wallet must not turn this into a session-only key. */}}
    if(!record){const master=await this.master(true);const iv=crypto.randomBytes(12);const cipher=crypto.createCipheriv('aes-256-gcm',master,iv);cipher.setAAD(Buffer.from(id));const data=Buffer.concat([cipher.update(key,'utf8'),cipher.final()]);record={mode:'local',iv:iv.toString('base64'),data:data.toString('base64'),tag:cipher.getAuthTag().toString('base64')};}
    await this.saveRecords({...this.records,[id]:record});
  }
  async delete(endpoint){const next={...this.records};delete next[this.id(endpoint)];await this.saveRecords(next);}
  async importLegacy(endpoint,encryptedKey){if(!this.has(endpoint))await this.saveRecords({...this.records,[this.id(endpoint)]:{mode:'native',data:encryptedKey}});}
}
