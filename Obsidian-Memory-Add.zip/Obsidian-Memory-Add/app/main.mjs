import {app, BrowserWindow, ipcMain, dialog, safeStorage, shell, Menu, net, clipboard, nativeImage} from 'electron';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';
import {DEFAULT_PROMPT,endpointUrl,canonicalUrl,fetchSource,analyze,listNotes,readParents,makePlan,commitPlan,history,undoTransaction,safePath,hash,preferredMainNotes,selectedMainFile} from './core.mjs';
import {CredentialStore} from './credentials.mjs';
import {openDirectory,boundedDesktopCall,setLinuxWindowIdentity} from './desktop.mjs';
if(process.platform==='win32')app.setAppUserModelId('com.hafiza.desktop');
if(process.platform==='linux')app.setDesktopName('hafiza.desktop');
const here=path.dirname(fileURLToPath(import.meta.url));
if(process.env.HAFIZA_TEST_DATA) app.setPath('userData',process.env.HAFIZA_TEST_DATA);
let win,config,credentials,source,analysis,parents,plan,controller,busy=false;
const defaults=()=>({baseUrl:'https://api.openai.com/v1',model:'gpt-4.1-mini',jsonMode:true,maxChars:60000,extra:'',vault:'',mainNotesByVault:{},activeProfile:'default',profiles:[{id:'default',name:'Genel Bilgi Toplama',prompt:DEFAULT_PROMPT}],versions:[]});
const configFile=()=>path.join(app.getPath('userData'),'settings.json');
const secure=()=>safeStorage.isEncryptionAvailable() && (process.platform!=='linux' || safeStorage.getSelectedStorageBackend()!=='basic_text');
async function persist(){await fs.mkdir(app.getPath('userData'),{recursive:true});const f=configFile();await fs.writeFile(f+'.tmp',JSON.stringify(config,null,2),{mode:0o600});await fs.rename(f+'.tmp',f);}
async function getKey(){return credentials.get(config.baseUrl);}
function publicConfig(){const {encryptedKey,...rest}=config;return {...rest,version:app.getVersion(),hasKey:credentials.has(config.baseUrl),keyStorage:credentials.mode(config.baseUrl),secureStorage:secure(),sessionOnly:false,defaultPrompt:DEFAULT_PROMPT};}
function resetDraft(){analysis=null;parents=null;plan=null;}
function requireVault(){if(!config.vault)throw new Error('Önce bir Obsidian vault klasörü seçin.');return config.vault;}
async function init(){
 try{config={...defaults(),...JSON.parse(await fs.readFile(configFile(),'utf8'))};}catch(e){if(e.code!=='ENOENT')throw new Error('Ayarlar okunamadı. settings.json dosyanızı yedekleyip kontrol edin.');config=defaults();}
 credentials=await new CredentialStore(app.getPath('userData'),{native:safeStorage,nativeAvailable:secure}).init();
 if(config.encryptedKey){await credentials.importLegacy(config.baseUrl,config.encryptedKey);delete config.encryptedKey;await persist();}
}
function handle(name,fn,{exclusive=false}={}){ipcMain.handle(name,async(event,...args)=>{if(event.sender!==win.webContents || event.senderFrame!==win.webContents.mainFrame)throw new Error('Geçersiz pencere.');if(exclusive&&busy) return {ok:false,error:'Devam eden işlemin tamamlanmasını bekleyin.'};if(exclusive)busy=true;try{return {ok:true,data:await fn(...args)};}catch(e){return {ok:false,error:e.name==='AbortError'?'İşlem iptal edildi.':e.name==='TimeoutError'?'İşlem zaman aşımına uğradı. Yeniden deneyin.':e.message};}finally{if(exclusive)busy=false;}});}
function register(){
 handle('settings:get',()=>publicConfig());
 handle('settings:save',async input=>{
  endpointUrl(input.baseUrl);
  if(!Array.isArray(input.profiles)||input.profiles.length<1||input.profiles.length>30)throw new Error('1–30 prompt profili gerekli.');
  for(const p of input.profiles)if(typeof p.id!=='string'||!p.name?.trim()||!p.prompt?.trim()||p.prompt.length>40000)throw new Error('Profil adı ve prompt gerekli; prompt en fazla 40.000 karakter olabilir.');
  if(!input.profiles.some(p=>p.id===input.activeProfile))throw new Error('Aktif profil bulunamadı.');
  const newKey=typeof input.apiKey==='string'?input.apiKey.trim():'';
  if(newKey==='************')throw new Error('Maskeli gösterge anahtar olarak kaydedilemez. Yeni anahtarı girin veya alanı değiştirmeden kaydedin.');
  if(input.removeKey&&newKey)throw new Error('Anahtarı silme ve yeni anahtar girme işlemlerini aynı anda seçmeyin.');
  if(input.removeKey)await credentials.delete(config.baseUrl);
  else if(newKey)await credentials.set(input.baseUrl,newKey);
  if(JSON.stringify(config.profiles)!==JSON.stringify(input.profiles)||config.extra!==input.extra){config.versions.unshift({id:crypto.randomUUID(),date:new Date().toISOString(),profiles:config.profiles,activeProfile:config.activeProfile,extra:config.extra});config.versions=config.versions.slice(0,20);}
  config={...config,baseUrl:input.baseUrl.trim(),model:String(input.model||'').trim().slice(0,150),jsonMode:!!input.jsonMode,maxChars:Math.max(4000,Math.min(200000,Number(input.maxChars)||60000)),extra:String(input.extra||'').slice(0,20000),profiles:input.profiles.map(p=>({id:p.id,name:p.name.slice(0,80),prompt:p.prompt})),activeProfile:input.activeProfile};
  await persist();resetDraft();return publicConfig();
 },{exclusive:true});
 handle('vault:choose',async()=>{
  const result=await dialog.showOpenDialog(win,{title:'Obsidian vault klasörünü seçin',properties:['openDirectory']});if(result.canceled)return null;
  const selected=await fs.realpath(result.filePaths[0]);
  try{await fs.access(path.join(selected,'.obsidian'));}catch{const answer=await dialog.showMessageBox(win,{type:'question',buttons:['Bu klasörü kullan','Vazgeç'],defaultId:0,cancelId:1,message:'Bu klasörde Obsidian ayarları bulunamadı.',detail:'Markdown klasörü olarak kullanabilirsiniz. Daha sonra Obsidian içinde vault olarak açın.'});if(answer.response!==0)return null;}
  const notes=await listNotes(selected);config.vault=selected;await persist();resetDraft();return {vault:selected,notes,preferredMainNotes:preferredMainNotes(notes,config.mainNotesByVault?.[selected]),history:await historySummary()};
 },{exclusive:true});
 handle('vault:notes',async()=>{const notes=config.vault?await listNotes(config.vault):[];return {vault:config.vault,notes,preferredMainNotes:preferredMainNotes(notes,config.mainNotesByVault?.[config.vault]),history:config.vault?await historySummary():[]};});
 handle('vault:select-main',async()=>{
  const root=requireVault();
  const result=await dialog.showOpenDialog(win,{title:'Ana hafıza dosyasını seç',defaultPath:path.join(root,config.mainNotesByVault?.[root]?.[0]||'IQ.md'),properties:['openFile'],filters:[{name:'Mevcut Markdown notu',extensions:['md']}]});
  if(result.canceled)return null;
  const relative=await selectedMainFile(root,result.filePaths[0]);
  config.mainNotesByVault={...config.mainNotesByVault,[root]:[relative]};await persist();resetDraft();
  return {notes:await listNotes(root),selected:[relative]};
 },{exclusive:true});
 handle('vault:create',async title=>{const root=requireVault();const name=String(title||'').trim();if(!name||name.length>90||/[<>:"/\\|?*\x00-\x1f#\[\]^]/.test(name)||/[. ]$/.test(name)||/^(con|prn|aux|nul|com\d|lpt\d)(\.|$)/i.test(name)||name.startsWith('.'))throw new Error('Geçerli bir not adı girin (en fazla 90 karakter).');const file=await safePath(root,name+'.md');await fs.writeFile(file,`# ${name}\n`,{flag:'wx'}).catch(e=>{if(e.code==='EEXIST')throw new Error('Bu isimde bir not zaten var.');throw e;});return await listNotes(root);},{exclusive:true});
 handle('source:fetch',async url=>{controller=new AbortController();resetDraft();source=null;try{source=await fetchSource(url,controller.signal,net.fetch.bind(net),{onProgress:stage=>{if(!win.isDestroyed())win.webContents.send('source:progress',stage);}});return source;}finally{controller=null;}},{exclusive:true});
 handle('source:manual',async({url,text,title})=>{if(typeof text!=='string'||text.trim().length<120||text.length>1000000)throw new Error('Metin 120–1.000.000 karakter arasında olmalı.');source={url:canonicalUrl(url),originalUrl:canonicalUrl(url),title:String(title||new URL(url).hostname),markdown:text.trim(),fetchedAt:new Date().toISOString(),author:'',published:'',manual:true};resetDraft();return source;},{exclusive:true});
 handle('analysis:run',async selected=>{if(!source)throw new Error('Önce kaynak içeriğini alın.');const root=requireVault();const old=await history(root);if(old.some(h=>['committed','prepared','conflict','undoing'].includes(h.status)&&(canonicalUrl(h.originalUrl)===canonicalUrl(source.originalUrl)||canonicalUrl(h.url)===canonicalUrl(source.url))))throw new Error('Bu kaynak daha önce aktarılmış. Geçmiş bölümünü kontrol edin.');parents=await readParents(root,selected);config.mainNotesByVault={...config.mainNotesByVault,[root]:parents.map(p=>p.path)};await persist();analysis=null;plan=null;controller=new AbortController();const profile=config.profiles.find(p=>p.id===config.activeProfile);analysis=await analyze(source,parents,{...config,prompt:profile.prompt},await getKey(),controller.signal);return analysis;},{exclusive:true});
 handle('analysis:test',async({text,prompt,extra})=>{if(typeof text!=='string'||text.length<120)throw new Error('Deneme metni en az 120 karakter olmalı.');controller=new AbortController();return await analyze({url:'https://example.com/prompt-denemesi',title:'Prompt denemesi',markdown:text.slice(0,200000)},[],{...config,prompt,extra},await getKey(),controller.signal);},{exclusive:true});
 handle('analysis:plan',async({result,mode})=>{if(!analysis||!parents||!source)throw new Error('Önce analiz yapın.');plan=await makePlan(requireVault(),source,{...result,model:analysis.model},parents,mode);return {id:plan.id,title:plan.title,changes:plan.changes.map(c=>({path:c.path,isNew:c.before===null,added:c.before===null?c.after:c.after.slice(c.before.trimEnd().length),full:c.after}))};},{exclusive:true});
 handle('analysis:commit',async id=>{if(!plan||plan.id!==id)throw new Error('Önizleme güncel değil. Yeniden önizleyin.');const record=await commitPlan(requireVault(),plan);resetDraft();return {record:{id:record.id,title:record.title},history:await historySummary()};},{exclusive:true});
 handle('history:list',()=>historySummary());
 handle('history:undo',async id=>{await undoTransaction(requireVault(),id);resetDraft();return historySummary();},{exclusive:true});
 handle('operation:cancel',()=>{controller?.abort();return true;});
 handle('vault:open',async()=>openDirectory(requireVault(),{nativeOpen:shell.openPath}));
 handle('vault:copy-path',()=>{const root=requireVault();clipboard.writeText(root);return root;});
 handle('note:open',async relative=>{const full=await safePath(requireVault(),relative);await fs.access(full);await boundedDesktopCall(()=>shell.openExternal(`obsidian://open?path=${encodeURIComponent(full)}`));});
 handle('profile:export',async profile=>{const r=await dialog.showSaveDialog(win,{defaultPath:'hafiza-prompt.json',filters:[{name:'Prompt profili',extensions:['json']}]});if(r.canceled)return false;await fs.writeFile(r.filePath,JSON.stringify({name:profile.name,prompt:profile.prompt},null,2));return true;},{exclusive:true});
 handle('profile:import',async()=>{const r=await dialog.showOpenDialog(win,{properties:['openFile'],filters:[{name:'Prompt profili',extensions:['json']}]});if(r.canceled)return null;const stat=await fs.stat(r.filePaths[0]);if(stat.size>100000)throw new Error('Profil dosyası çok büyük.');const p=JSON.parse(await fs.readFile(r.filePaths[0],'utf8'));if(typeof p.name!=='string'||typeof p.prompt!=='string'||!p.prompt.trim()||p.prompt.length>40000)throw new Error('Geçerli name ve prompt alanları gerekli.');return {id:crypto.randomUUID(),name:p.name.slice(0,80),prompt:p.prompt};},{exclusive:true});
}
async function historySummary(){return (await history(requireVault())).map(({id,title,url,createdAt,status,changes})=>({id,title,url,createdAt,status,files:changes.map(c=>c.path)}));}
function createWindow(){const windowIcon=nativeImage.createFromPath(path.join(here,'assets',process.platform==='win32'?'icon.ico':'icon.png'));if(windowIcon.isEmpty())throw new Error('Uygulama simgesi yüklenemedi. Uygulamayı yeniden kurun.');const taskbarIcon=process.platform==='linux'?windowIcon.resize({width:128,height:128,quality:'best'}):windowIcon;win=new BrowserWindow({width:1320,height:900,minWidth:1000,minHeight:720,title:'Hafıza',backgroundColor:'#f7f8fa',skipTaskbar:false,icon:taskbarIcon,webPreferences:{preload:path.join(here,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}});Menu.setApplicationMenu(null);if(process.platform==='linux')void setLinuxWindowIdentity(win.getNativeWindowHandle().readUInt32LE(0));win.webContents.on('will-prevent-unload',event=>{const choice=dialog.showMessageBoxSync(win,{type:'question',buttons:['Çalışmaya dön','Yine de kapat'],defaultId:0,cancelId:0,message:'Kaydedilmemiş ayarlar veya devam eden bir işlem var.',detail:'Kapatırsanız kaydedilmemiş ayarlar kaybolur. Yarım kalan kayıtlar Geçmiş bölümünden kurtarılabilir.'});if(choice===1){controller?.abort();event.preventDefault();}});win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.on('will-navigate',e=>e.preventDefault());win.webContents.session.setPermissionRequestHandler((_w,_p,callback)=>callback(false));win.loadFile(path.join(here,'../ui/index.html'));}
if(!app.requestSingleInstanceLock())app.quit();else{app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.focus();}});app.whenReady().then(async()=>{await init();register();createWindow();}).catch(e=>{dialog.showErrorBox('Hafıza açılamadı',e.message);app.quit();});app.on('window-all-closed',()=>app.quit());}
