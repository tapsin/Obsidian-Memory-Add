import fs from 'node:fs/promises';
import {execFile} from 'node:child_process';

export function desktopEnvironment(original=process.env){
  const env={...original};const appdir=env.APPDIR;
  for(const key of ['LD_LIBRARY_PATH','LD_PRELOAD','XDG_DATA_DIRS','QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH','GIO_EXTRA_MODULES','GDK_PIXBUF_MODULE_FILE']){
    if(!env[key])continue;
    const parts=env[key].split(':').filter(part=>!part.startsWith('/tmp/.mount_')&&!(appdir&&(part===appdir||part.startsWith(appdir+'/'))));
    if(parts.length)env[key]=parts.join(':');else delete env[key];
  }
  delete env.APPDIR;delete env.APPIMAGE;delete env.ARGV0;
  return env;
}
export async function boundedDesktopCall(operation,timeoutMs=7000){
  let timer;
  try{return await Promise.race([Promise.resolve().then(operation),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Masaüstü uygulaması yanıt vermedi. Dosya yolunu kopyalayıp dosya yöneticisinde açabilirsiniz.')),timeoutMs);})]);}
  finally{clearTimeout(timer);}
}
export async function openDirectory(directory,{platform=process.platform,nativeOpen,execute=execFile,timeoutMs=6000,env=process.env}={}){
  if(!(await fs.stat(directory)).isDirectory())throw new Error('Vault klasörü bulunamadı. Klasörü yeniden seçin.');
  if(platform!=='linux'){
    const error=await boundedDesktopCall(()=>nativeOpen(directory),timeoutMs);
    if(error)throw new Error('Klasör açılamadı. Vault yolunu kopyalayıp dosya yöneticisine yapıştırın.');
    return {opened:true};
  }
  // Use a tracked, bounded child process rather than an unresolved shell.openPath promise.
  // AppImage library paths must not leak into the system's file manager.
  let launcher='/usr/bin/gio';let args=['open',directory];
  try{await fs.access(launcher);}catch{launcher='/usr/bin/xdg-open';args=[directory];}
  await new Promise((resolve,reject)=>{
    execute(launcher,args,{env:desktopEnvironment(env),timeout:timeoutMs,killSignal:'SIGTERM',windowsHide:true,maxBuffer:65536},error=>{
      if(!error)return resolve();
      if(error.killed||error.code==='ETIMEDOUT')return reject(new Error('Dosya yöneticisi yanıt vermedi. “Vault yolunu kopyala” ile klasör yolunu alıp dosya yöneticisine yapıştırın. Not aktarımı için klasörü açmanız gerekmez.'));
      reject(new Error('Dosya yöneticisi klasörü açamadı. “Vault yolunu kopyala” ile klasöre elle ulaşabilirsiniz. Not aktarımı için klasörü açmanız gerekmez.'));
    });
  });
  return {opened:true};
}

// KDE can fail to associate an AppImage's temporary executable with its launcher.
// Supply the desktop entry ID on X11 when xprop is available; other desktops use
// the native window icon and the application desktop name without this hint.
export function setLinuxWindowIdentity(windowId,{platform=process.platform,env=process.env,execute=execFile}={}){
  if(platform!=='linux'||!env.DISPLAY||!Number.isSafeInteger(windowId)||windowId<=0)return Promise.resolve(false);
  return new Promise(resolve=>{
    execute('/usr/bin/xprop',['-id',`0x${windowId.toString(16)}`,'-f','_KDE_NET_WM_DESKTOP_FILE','8u','-set','_KDE_NET_WM_DESKTOP_FILE','hafiza'],{env:desktopEnvironment(env),timeout:1500,windowsHide:true,maxBuffer:8192},error=>resolve(!error));
  });
}
